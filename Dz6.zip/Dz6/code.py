e = int(input("E:"))
fi = int(input("fi:"))
x = 1

while True:
    if (x * e) % fi == 1 and x != e and x != fi:
        break
    x += 1
print(f"valid {x}")